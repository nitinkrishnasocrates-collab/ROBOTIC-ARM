// ============================================================================
// MEMBER 1: SENSOR ACQUISITION & SIGNAL FILTERING
// ============================================================================
int readCleanPot(int pin) {
  analogRead(pin);            // Flush ADC
  delayMicroseconds(50);
  int raw = analogRead(pin);
  return (raw < 30) ? 0 : raw;
}

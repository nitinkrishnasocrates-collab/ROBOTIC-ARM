// ============================================================================
// ROBOTIC ARM SYSTEM - 3-Axis Gesture & Memory Core
// Tabs: Config.h | Sensors | Kinematics | Memory | Telemetry
// ============================================================================
#include <Wire.h>
#include <MPU6050_light.h>
#include <Servo.h>
#include "Config.h"

// ============================================================================
// GLOBAL STATE & STORAGE
// ============================================================================
MPU6050 mpu(Wire);
Servo servo_base, servo_shoulder, servo_holder;
bool mpu_online = false;

// Member 3: Step Memory
int recorded_moves[MAX_STEPS][3];
int step_count = 0;
bool is_playing = false;
int play_index = 0;

// Member 2: Targets & Current Angles
int target_base = 90, target_shoulder = 30, target_holder = 0;
float cur_base = 90.0, cur_shoulder = 30.0, cur_holder = 0.0;

// System Timers
unsigned long timer_imu    = 0;
unsigned long timer_pot    = 0;
unsigned long timer_servo  = 0;
unsigned long timer_play   = 0;
unsigned long timer_status = 0;

// ============================================================================
// SYSTEM BOOTLOADER
// ============================================================================
void setup() {
  Serial.begin(9600);
  Wire.begin();

  Serial.println(F("\n****************************************"));
  Serial.println(F("*         ROBOTIC ARM SYSTEM           *"));
  Serial.println(F("*     3-Axis Gesture & Memory Core     *"));
  Serial.println(F("****************************************"));
  Serial.println(F("[BOOT] Initializing hardware..."));

  servo_base.attach(PIN_BASE);
  servo_shoulder.attach(PIN_SHOULD);
  servo_holder.attach(PIN_HOLD);
  servo_base.write(target_base);
  servo_shoulder.write(target_shoulder);
  servo_holder.write(target_holder);

  pinMode(PIN_STORE, INPUT_PULLUP);
  pinMode(PIN_PLAY,  INPUT_PULLUP);
  Serial.println(F("[BOOT] Servos homed and ready."));

  Serial.print(F("[BOOT] Calibrating MPU6050 (keep still)... "));
  byte status = mpu.begin();
  if (status == 0) {
    mpu_online = true;
    delay(1000);
    mpu.calcOffsets();
    Serial.println(F("DONE"));
  } else {
    Serial.print(F("FAILED (Code "));
    Serial.print(status);
    Serial.println(F(")"));
  }

  Serial.println(F("----------------------------------------"));
  Serial.println(F(">> SYSTEM READY: LIVE GESTURE MODE <<"));
  Serial.println(F(">> Press D2 to Store | D3 to Play <<"));
  Serial.println(F("----------------------------------------\n"));
}

// ============================================================================
// MAIN LOOP
// ============================================================================
void loop() {
  if (mpu_online) mpu.update();

  handleButtons();

  if (is_playing) {
    executePlayback();
  } else {
    processKinematics();
  }

  // 50Hz Damped Motion
  if (millis() - timer_servo >= 20) {
    timer_servo = millis();
    updateServoDamped(servo_base,     cur_base,     target_base,     SMOOTH_BASE);
    updateServoDamped(servo_shoulder, cur_shoulder, target_shoulder, SMOOTH_SHOULDER);
    updateServoDamped(servo_holder,   cur_holder,   target_holder,   SMOOTH_HOLDER);
  }

  reportStatus();
}

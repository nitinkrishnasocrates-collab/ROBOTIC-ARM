// ============================================================================
// MEMBER 2: KINEMATICS & DAMPING ENGINE
// ============================================================================
void updateServoDamped(Servo &s, float &cur, int target, float factor) {
  cur += (target - cur) * factor;
  s.write((int)round(cur));
}

void processKinematics() {
  if (mpu_online && (millis() - timer_imu >= 100)) {
    timer_imu = millis();
    int clamped_x = constrain((int)mpu.getAngleX(), -30, 30);
    int clamped_y = constrain((int)mpu.getAngleY(), -30, 30);
    target_base     = map(clamped_x, -30, 30, 180, 0);
    target_shoulder = map(clamped_y, -30, 30, 60, 0);
  }

  if (millis() - timer_pot >= 40) {
    timer_pot = millis();
    target_holder = map(readCleanPot(PIN_POT), 0, 1023, 0, 30);
  }
}

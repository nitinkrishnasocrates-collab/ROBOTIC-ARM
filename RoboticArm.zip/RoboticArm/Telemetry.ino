// ============================================================================
// MEMBER 4: BEAUTIFIED TELEMETRY
// ============================================================================
void reportStatus() {
  if (millis() - timer_status >= 1000) {
    timer_status = millis();

    if (!is_playing) {
      Serial.print(F("[STATUS] Live Mode | Steps Saved: "));
      Serial.print(step_count);
      Serial.print(F("/5 | Live Base: "));
      Serial.print(target_base);
      Serial.print(F("° | Shoulder: "));
      Serial.print(target_shoulder);
      Serial.print(F("° | Clipper: "));
      Serial.print(target_holder);
      Serial.println(F("°"));
    }
  }
}

// ============================================================================
// MEMBER 3: STATE MACHINE & STEP MEMORY
// ============================================================================
void handleButtons() {
  // Store Pose (D2)
  if (digitalRead(PIN_STORE) == LOW) {
    if (step_count < MAX_STEPS) {
      recorded_moves[step_count][0] = target_base;
      recorded_moves[step_count][1] = target_shoulder;
      recorded_moves[step_count][2] = target_holder;
      step_count++;

      Serial.print(F("\n[STORED] Step "));
      Serial.print(step_count);
      Serial.print(F(" of "));
      Serial.print(MAX_STEPS);
      Serial.print(F(" -> Base: "));
      Serial.print(target_base);
      Serial.print(F("° | Shoulder: "));
      Serial.print(target_shoulder);
      Serial.print(F("° | Clipper: "));
      Serial.print(target_holder);
      Serial.println(F("°"));
    } else {
      Serial.println(F("\n[WARNING] Memory Full! Maximum 5 steps recorded."));
    }
    delay(250);
  }

  // Play / Pause Toggle (D3)
  if (digitalRead(PIN_PLAY) == LOW) {
    if (step_count > 0) {
      is_playing = !is_playing;
      play_index = 0;
      timer_play = millis();

      if (is_playing) {
        Serial.println(F("\n========================================"));
        Serial.println(F("       >>> PLAYING SEQUENCE <<<         "));
        Serial.println(F("========================================"));
      } else {
        Serial.println(F("\n========================================"));
        Serial.println(F("       || PAUSED - LIVE CONTROL ||      "));
        Serial.println(F("========================================"));
      }
    } else {
      Serial.println(F("\n[ERROR] No steps saved yet! Store poses first."));
    }
    delay(250);
  }
}

void executePlayback() {
  if (millis() - timer_play >= 1500) {
    timer_play = millis();

    target_base     = recorded_moves[play_index][0];
    target_shoulder = recorded_moves[play_index][1];
    target_holder   = recorded_moves[play_index][2];

    Serial.print(F(" -> Executing Step "));
    Serial.print(play_index + 1);
    Serial.print(F(" [Base: "));
    Serial.print(target_base);
    Serial.print(F("°, Shoulder: "));
    Serial.print(target_shoulder);
    Serial.print(F("°, Clipper: "));
    Serial.print(target_holder);
    Serial.println(F("°]"));

    play_index = (play_index + 1) % step_count;
  }
}

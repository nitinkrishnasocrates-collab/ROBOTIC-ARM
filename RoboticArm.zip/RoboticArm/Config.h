#ifndef CONFIG_H
#define CONFIG_H

// ============================================================================
// HARDWARE PIN DEFINITIONS
// ============================================================================
const int PIN_POT    = A0;  // Member 1: Potentiometer
const int PIN_STORE  = 2;   // Member 3: Store button (D2)
const int PIN_PLAY   = 3;   // Member 3: Play/Pause button (D3)
const int PIN_BASE   = 9;   // Member 4: Base Servo (X)
const int PIN_SHOULD = 10;  // Member 4: Shoulder Servo (Y)
const int PIN_HOLD   = 11;  // Member 4: Clipper Servo

// ============================================================================
// SETTINGS
// ============================================================================
const int MAX_STEPS = 5;

const float SMOOTH_BASE     = 0.10;
const float SMOOTH_SHOULDER = 0.04;
const float SMOOTH_HOLDER   = 0.10;

#endif
